CREATE TABLE paryoll_hdr(
pay_period_id	INT IDENTITY(1,1)	NOT NULL
,period_date_from	DATE	NULL
,period_date_to	DATE	NULL
,pay_type_id	INT	NULL
,status_id	INT	NULL
,created_by	INT	NULL
,created_date	DATE	NULL)