CREATE TYPE trend_menus_tt AS TABLE(
menu_id	INT	NULL
,is_edited	CHAR(1)	NULL
,menu_name	VARCHAR(50)	NULL
,menu_type	VARCHAR(50)	NULL
,seq_no	INT	NULL
,specs_id	INT	NULL)