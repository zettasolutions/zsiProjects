CREATE TYPE page_templates_tt AS TABLE(
pt_id	INT	NULL
,page_id	INT	NOT NULL
,pt_content	NVARCHAR(0)	NULL)