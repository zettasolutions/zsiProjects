CREATE TABLE statuses(
status_code	CHAR(1)	NOT NULL
,status_desc	NVARCHAR(100)	NULL
,status_color	NVARCHAR(100)	NULL)