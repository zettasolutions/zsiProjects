CREATE VIEW [dbo].[regions_v]
AS
SELECT DISTINCT region_name
FROM            dbo.cutsheets_v



