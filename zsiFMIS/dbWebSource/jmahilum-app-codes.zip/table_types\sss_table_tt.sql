CREATE TYPE sss_table_tt AS TABLE(
id	INT	NULL
,is_edited	CHAR(1)	NULL
,salary_fr	DECIMAL(20)	NULL
,salary_to	DECIMAL(20)	NULL
,msc	DECIMAL(20)	NULL
,ssc_er	DECIMAL(20)	NULL
,ssc_ee	DECIMAL(20)	NULL
,ecc_er	DECIMAL(20)	NULL)