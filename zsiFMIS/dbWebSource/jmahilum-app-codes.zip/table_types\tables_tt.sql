CREATE TYPE tables_tt AS TABLE(
table_id	INT	NULL
,table_code	VARCHAR(50)	NULL
,table_name	VARCHAR(50)	NULL
,table_key_name	VARCHAR(50)	NULL)