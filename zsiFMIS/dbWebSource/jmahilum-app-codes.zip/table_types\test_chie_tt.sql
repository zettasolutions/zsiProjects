CREATE TYPE test_chie_tt AS TABLE(
id	INT	NULL
,is_edited	CHAR(1)	NULL
,name	NVARCHAR(100)	NULL
,lastname	NVARCHAR(100)	NULL
,province	NVARCHAR(100)	NULL
,monthly_salary	DECIMAL(32)	NULL)