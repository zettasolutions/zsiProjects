CREATE TYPE test_criterias_tt AS TABLE(
criteria_id	INT	NULL
,trend_menu_id	INT	NULL
,is_edited	CHAR(1)	NULL
,seq_no	INT	NULL
,criteria_title	VARCHAR(50)	NULL
,pcriteria_id	INT	NULL
,is_active	CHAR(1)	NULL)