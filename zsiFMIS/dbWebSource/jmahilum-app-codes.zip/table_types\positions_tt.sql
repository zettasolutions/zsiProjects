CREATE TYPE positions_tt AS TABLE(
position_id	INT	NULL
,is_edited	CHAR(1)	NULL
,position_code	VARCHAR(50)	NULL
,position	VARCHAR(50)	NULL
,is_active	VARCHAR(1)	NULL)