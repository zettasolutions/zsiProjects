CREATE TABLE users_key(
id	INT IDENTITY(1,1)	NOT NULL
,user_id	INT	NOT NULL
,password	TEXT(2147483647)	NOT NULL
,created_by	VARCHAR(100)	NULL
,created_date	DATETIME	NULL
,updated_by	NVARCHAR(400)	NULL
,updated_date	DATETIME	NULL)