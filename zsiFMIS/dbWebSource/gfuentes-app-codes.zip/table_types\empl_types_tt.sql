CREATE TYPE empl_types_tt AS TABLE(
empl_type_code	NCHAR(20)	NULL
,empl_type_desc	NVARCHAR(100)	NULL)