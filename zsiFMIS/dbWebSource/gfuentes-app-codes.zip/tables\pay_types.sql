CREATE TABLE pay_types(
pay_type_code	NCHAR(20)	NULL
,pay_type_desc	NVARCHAR(100)	NULL)