CREATE TABLE leave_types(
leave_type_id	INT IDENTITY(1,1)	NOT NULL
,leave_code	NVARCHAR(100)	NULL
,leave_type	NVARCHAR(100)	NULL)