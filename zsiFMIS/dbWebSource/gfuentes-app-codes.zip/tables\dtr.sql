CREATE TABLE dtr(
id	INT	NOT NULL
,employee_id	INT	NULL
,dt_in	DATETIME	NULL
,dt_out	DATETIME	NULL
,shift_id	INT	NULL
,reg_hours	DECIMAL(20)	NULL
,nd_hours	DECIMAL(20)	NULL
,total_hours	DECIMAL(20)	NULL)