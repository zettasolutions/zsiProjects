CREATE TYPE hmdf_table_tt AS TABLE(
id	INT	NULL
,is_edited	CHAR(1)	NULL
,salary_fr	DECIMAL(20)	NULL
,salary_to	DECIMAL(20)	NULL
,ee_pct_share	DECIMAL(20)	NULL
,er_pct_share	DECIMAL(20)	NULL)