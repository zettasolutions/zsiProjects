CREATE TABLE vehicle_daily_checklist(
id	INT IDENTITY(1,1)	NOT NULL
,code	NVARCHAR(100)	NULL
,work_desc	NVARCHAR(200)	NULL)