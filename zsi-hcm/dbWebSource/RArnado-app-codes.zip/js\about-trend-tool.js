zsi.ready = function(){  
   // $("#grid").colResizable({liveDrag:true,fixed:false,});
    $(".zAboutTTWrapper").css({
            height:$(window).height()-50
        });     
     
    
};    