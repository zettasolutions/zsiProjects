CREATE TABLE duty_rest_day(
duty_rest_day_id	INT	NOT NULL
,duty_rest_day	NVARCHAR(100)	NULL)