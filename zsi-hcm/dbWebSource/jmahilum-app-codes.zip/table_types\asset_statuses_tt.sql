CREATE TYPE asset_statuses_tt AS TABLE(
asset_status_id	INT	NULL
,asset_status_code	NVARCHAR(100)	NULL
,asset_status	NVARCHAR(100)	NULL)