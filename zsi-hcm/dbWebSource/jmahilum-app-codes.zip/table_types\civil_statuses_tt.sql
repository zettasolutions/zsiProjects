CREATE TYPE civil_statuses_tt AS TABLE(
civil_status_code	NCHAR(20)	NULL
,civil_status_desc	NVARCHAR(100)	NULL)