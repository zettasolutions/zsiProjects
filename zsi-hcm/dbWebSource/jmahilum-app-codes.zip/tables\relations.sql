CREATE TABLE relations(
relation_id	INT IDENTITY(1,1)	NOT NULL
,relation	NVARCHAR(100)	NULL)