CREATE TYPE vehicle_daily_checklist_tt AS TABLE(
id	INT	NULL
,code	NVARCHAR(100)	NULL
,work_desc	NVARCHAR(200)	NULL)