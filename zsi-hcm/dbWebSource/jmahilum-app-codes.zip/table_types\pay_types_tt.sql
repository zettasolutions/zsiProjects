CREATE TYPE pay_types_tt AS TABLE(
pay_type_code	NVARCHAR(20)	NULL
,pay_type_desc	NVARCHAR(100)	NULL)