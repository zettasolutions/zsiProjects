



CREATE VIEW [dbo].[user_role_v]
AS
SELECT * FROM dbo.users_v

