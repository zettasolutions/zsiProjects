CREATE TABLE asset_statuses(
asset_status_id	INT IDENTITY(1,1)	NOT NULL
,asset_status_code	NVARCHAR(100)	NULL
,asset_status	NVARCHAR(100)	NULL)