CREATE TYPE role_dashboards_tt AS TABLE(
role_dashboard_id	INT	NULL
,is_edited	NVARCHAR(4)	NULL
,role_id	INT	NULL
,page_id	INT	NULL
,seq_no	INT	NULL)