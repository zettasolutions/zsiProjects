CREATE TYPE test_table_tt AS TABLE(
id	INT	NULL
,is_edited	CHAR(1)	NULL
,name	VARCHAR(50)	NULL
,age	NVARCHAR(100)	NULL
,salary	CHAR(1)	NULL)