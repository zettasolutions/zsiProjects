CREATE TABLE tables(
table_id	INT IDENTITY(1,1)	NOT NULL
,table_code	VARCHAR(50)	NULL
,table_name	VARCHAR(50)	NULL
,table_key_name	VARCHAR(50)	NULL)