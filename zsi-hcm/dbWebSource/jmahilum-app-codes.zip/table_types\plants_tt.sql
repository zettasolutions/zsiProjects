CREATE TYPE plants_tt AS TABLE(
plant_id	INT	NULL
,is_edited	CHAR(1)	NULL
,plant_code	VARCHAR(50)	NULL
,plant_name	VARCHAR(50)	NULL
,plant_address	VARCHAR(5000)	NULL
,is_active	VARCHAR(1)	NULL)