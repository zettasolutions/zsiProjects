CREATE TYPE regions_tt AS TABLE(
region_id	INT	NULL
,is_edited	CHAR(1)	NULL
,region_code	VARCHAR(50)	NULL
,region_name	VARCHAR(50)	NULL
,is_active	VARCHAR(1)	NULL)