CREATE TYPE other_income_tt AS TABLE(
other_income_id	INT	NULL
,is_edited	CHAR(1)	NULL
,other_income_code	NVARCHAR(100)	NULL
,other_income_desc	NVARCHAR(400)	NULL)