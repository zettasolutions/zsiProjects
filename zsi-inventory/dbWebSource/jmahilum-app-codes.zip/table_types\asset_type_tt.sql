CREATE TYPE asset_type_tt AS TABLE(
id	INT	NULL
,asset_code	NVARCHAR(100)	NULL
,asset_type	NVARCHAR(200)	NULL)