CREATE TABLE inactive_types(
inactive_type_code	NCHAR(20)	NULL
,inactive_type_desc	NVARCHAR(100)	NULL)