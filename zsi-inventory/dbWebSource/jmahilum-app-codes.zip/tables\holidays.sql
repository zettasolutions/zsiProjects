CREATE TABLE holidays(
holiday_id	INT	NOT NULL
,holiday_date	DATE	NULL
,holiday_title	NVARCHAR(100)	NULL
,is_regular	CHAR(1)	NULL
,created_by	INT	NULL
,created_date	DATE	NULL
,updated_by	INT	NULL
,updated_date	DATE	NULL)