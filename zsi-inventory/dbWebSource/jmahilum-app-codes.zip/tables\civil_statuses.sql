CREATE TABLE civil_statuses(
civil_status_code	NCHAR(20)	NULL
,civil_status_desc	NVARCHAR(100)	NULL)