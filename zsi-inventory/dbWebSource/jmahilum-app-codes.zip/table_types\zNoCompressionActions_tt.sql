CREATE TYPE zNoCompressionActions_tt AS TABLE(
id	INT	NULL
,actionname	NVARCHAR(200)	NULL)