﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NexgenPLBCompiler
{
    public class CompilePLB 
    {

        
        public CompilePLB(string logonName ,string password, string version, string tnsName, CheckProcess onCheckProcess) {
            this.fileName =  string.Format("{0}.{1}.{2}.txt", logonName, tnsName, version);
            this.path = string.Format("{0}\\{1}", this.subFolder,this.fileName);
            this.logonName = logonName;
            this.password = password;
            this.version= version;
            this.tnsName= tnsName;

            if ( ! Directory.Exists(this.subFolder)) Directory.CreateDirectory(this.subFolder);
            var myFile = File.Create(this.path);
            myFile.Close();
            this.onCheckProcess = onCheckProcess;
        }
        string subFolder = "result";
        string fileName { get; set; }
        string path{ get; set; }
        private CheckProcess onCheckProcess { get; set; }
        private string logonName { get; set; }
        private string password { get; set; }
        private string version { get; set; }
        private string tnsName { get; set; }
        private int CountCompile { get; set; }

        public void Execute()
        {
            string userPass  = logonName + "/" + this.password+ "@" + this.tnsName;

            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.CreateNoWindow = true;

            p.StartInfo.FileName = "compileplb.bat";
            p.StartInfo.Arguments = string.Format("{0} {1}", userPass, this.version);

            p.EnableRaisingEvents = true;
            p.OutputDataReceived += new System.Diagnostics.DataReceivedEventHandler(Compile_OutputDataReceived);
            p.ErrorDataReceived += new System.Diagnostics.DataReceivedEventHandler(Compile_ErrorDataReceived);
            p.Exited += new EventHandler(Compile_Exited);
            p.Start();


            p.StandardInput.WriteLine("exit");


            p.BeginErrorReadLine();
            p.BeginOutputReadLine();

        }
        private void Compile_OutputDataReceived(object sender, System.Diagnostics.DataReceivedEventArgs e)
        {
            if (e.Data != null)
            {
                using (StreamWriter sw = File.AppendText(this.path))
                {
                    sw.WriteLine(e.Data);
                }

            }
        }

        private void Compile_ErrorDataReceived(object sender, System.Diagnostics.DataReceivedEventArgs e)
        {
            if (e.Data != null)
            {
                if (e.Data.Contains("cannot find")) return;
                using (StreamWriter sw = File.AppendText(this.path))
                {
                    sw.WriteLine(e.Data);
                    System.Media.SystemSounds.Exclamation.Play();
                }

            }

        }
        private void Compile_Exited(object sender, EventArgs e)
        {
            this.CountCompile += 1;
            using (StreamWriter sw = File.AppendText(this.path))
            {
                sw.WriteLine("-----done----");
               this.onCheckProcess(this.logonName,this.version, this.fileName);
            }

        }

    }

}
