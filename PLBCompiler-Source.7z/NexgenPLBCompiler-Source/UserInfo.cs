﻿using System.Collections.Generic;
namespace NexgenPLBCompiler
{
    public class UserInfo
    {
        public UserInfo(string name)
        {
            this.name = name;
            this.versions = new List<string>();
        }
        public void remove(string name) {

        }
        public string name { get; set; }
        public List<string> versions = new List<string>();
    }
}
