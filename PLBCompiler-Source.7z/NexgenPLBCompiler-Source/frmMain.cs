﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;


namespace NexgenPLBCompiler
{
    delegate void Function();
    public partial class frmMain : Form
    {
        private string Password { get { return System.Configuration.ConfigurationManager.AppSettings["Password"].ToString(); } }
        private string tnsName { get { return System.Configuration.ConfigurationManager.AppSettings["tnsName"].ToString(); } }
        private int CountCompileStart { get; set; }
        private int CountCompileDone { get; set; }
        private List<UserInfo> UserList { get; set; } 
        private List<Thread> ThreadList { get; set; }
        public frmMain()
        {
            InitializeComponent();
        }
        private string Directory{get;set;}

        private void compilePLB(string logonName, string version)
        {

            ThreadStart threadStart = new ThreadStart( new CompilePLB(logonName, this.Password, version,this.tnsName, onCheckProcess).Execute );
            Thread t = new Thread(threadStart);
            t.Start();

            ThreadList = new List<Thread>();
            ThreadList.Add(t);
        }
        private void onCheckProcess() {
            this.CountCompileDone++;

            this.Invoke(new Function(delegate ()
            {
                this.txtCurrentProcess.Text = this.CountCompileDone.ToString();
            }));

            if (CountCompileStart == CountCompileDone) { 
                MessageBox.Show("Batch file compile has been successfully done.");
            }
        }
 
        private void Form1_Load(object sender, EventArgs e)
        {
            UserList = new List<UserInfo>();
            loadTextFile(clbLogon, "logons.txt");
           
        }

 
        private void loadTextFile(CheckedListBox clb, string fileName) {


            string[] lines = File.ReadAllLines(fileName);
            foreach (string line in lines)
            {
                clb.Items.Add(line);
            }
        }

        private void clbLogon_SelectedValueChanged(object sender, EventArgs e)
        {
            string logonName = clbLogon.SelectedItem.ToString();
            clbVersions.Items.Clear();
            cbVersions.Checked = false;
            loadTextFile(clbVersions, "versions.txt");
            loadLogonVersions(logonName);

        }

        private void clbVersions_SelectedValueChanged(object sender, EventArgs e)
        {
            bool isChecked = (((CheckedListBox)sender).GetItemCheckState(((CheckedListBox)sender).SelectedIndex).ToString().ToLower() == "checked" ? true: false) ;

            string logonName = clbLogon.SelectedItem.ToString();
            string version = ((CheckedListBox)sender).SelectedItem.ToString();
            UserInfo info = UserList.Find(x => x.name.Contains(logonName));

            if (info != null) {
                bool exists = info.versions.Exists(x => x==version);
                if (! exists && isChecked) info.versions.Add(version);
                if (exists && ! isChecked) info.versions.Remove(version);
            }
        }

        private void loadLogonVersions(string name)
        {
            UserInfo info = GetLogonInfo(name);
            if (info == null)
            {
                UserList.Add(new UserInfo(name));
                CheckUncheckAll(clbVersions, false);
                return;
            }

            foreach (string line in info.versions)
            {
                int i = clbVersions.FindString(line);
                if(i>-1) clbVersions.SetItemChecked(i, true);
            }
        }

        private UserInfo GetLogonInfo(string name)
        {
            return UserList.Find(x => x.name.Contains(name));
        }

        private void CheckUncheckAll(CheckedListBox clb, bool check)
        {
            for( var i=0; i < clb.Items.Count;i++)
            {
                clb.SetItemChecked(i,check);
            }
        }

        private void cbLogons_CheckedChanged(object sender, EventArgs e)
        {
            CheckUncheckAll(clbLogon, cbLogons.Checked);
        }

        private void cbVersions_CheckedChanged(object sender, EventArgs e)
        {
           if (clbLogon.SelectedItem == null) return;
           CheckUncheckAll(clbVersions, cbVersions.Checked);

            if (cbVersions.Checked) {

                string logonName = clbLogon.SelectedItem.ToString();
                UserInfo info= UserList.Find(x => x.name.Contains(logonName));
                if (info != null)
                {
                    var clb = clbVersions;
                    for (var i = 0; i < clb.Items.Count; i++)
                    {
                        clb.SetItemChecked(i, true);
                        info.versions.Add(clb.Items[i].ToString());
                    }
                    
                }

            }

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            resetCounter();
            foreach (UserInfo info in UserList)
            {
                foreach (string version in info.versions)
                {
                    this.CountCompileStart++;
                    compilePLB(info.name, version);
                }
            }

            this.txtTotalProcess.Text = this.CountCompileStart.ToString();
        }

        private void resetCounter() {
            this.CountCompileStart = 0;
            this.CountCompileDone = 0;
            this.txtTotalProcess.Text = "0";
            this.txtCurrentProcess.Text = "0";
        }

    }


    

}
