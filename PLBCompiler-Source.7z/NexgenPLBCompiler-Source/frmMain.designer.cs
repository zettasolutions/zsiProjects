﻿namespace NexgenPLBCompiler
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRun = new System.Windows.Forms.Button();
            this.clbLogon = new System.Windows.Forms.CheckedListBox();
            this.clbVersions = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbLogons = new System.Windows.Forms.CheckBox();
            this.cbVersions = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTotalProcess = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCurrentProcess = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(312, 21);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 38);
            this.btnRun.TabIndex = 2;
            this.btnRun.Text = "&Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // clbLogon
            // 
            this.clbLogon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.clbLogon.FormattingEnabled = true;
            this.clbLogon.Location = new System.Drawing.Point(12, 55);
            this.clbLogon.Name = "clbLogon";
            this.clbLogon.Size = new System.Drawing.Size(153, 424);
            this.clbLogon.TabIndex = 17;
            this.clbLogon.SelectedValueChanged += new System.EventHandler(this.clbLogon_SelectedValueChanged);
            // 
            // clbVersions
            // 
            this.clbVersions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.clbVersions.CheckOnClick = true;
            this.clbVersions.FormattingEnabled = true;
            this.clbVersions.Location = new System.Drawing.Point(174, 55);
            this.clbVersions.Name = "clbVersions";
            this.clbVersions.Size = new System.Drawing.Size(62, 424);
            this.clbVersions.TabIndex = 18;
            this.clbVersions.SelectedValueChanged += new System.EventHandler(this.clbVersions_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Logon Names:";
            // 
            // cbLogons
            // 
            this.cbLogons.AutoSize = true;
            this.cbLogons.Location = new System.Drawing.Point(15, 33);
            this.cbLogons.Name = "cbLogons";
            this.cbLogons.Size = new System.Drawing.Size(71, 17);
            this.cbLogons.TabIndex = 21;
            this.cbLogons.Text = "Check All";
            this.cbLogons.UseVisualStyleBackColor = true;
            this.cbLogons.CheckedChanged += new System.EventHandler(this.cbLogons_CheckedChanged);
            // 
            // cbVersions
            // 
            this.cbVersions.AutoSize = true;
            this.cbVersions.Location = new System.Drawing.Point(174, 33);
            this.cbVersions.Name = "cbVersions";
            this.cbVersions.Size = new System.Drawing.Size(71, 17);
            this.cbVersions.TabIndex = 22;
            this.cbVersions.Text = "Check All";
            this.cbVersions.UseVisualStyleBackColor = true;
            this.cbVersions.CheckedChanged += new System.EventHandler(this.cbVersions_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(171, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Versions:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(242, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Total Processes:";
            // 
            // txtTotalProcess
            // 
            this.txtTotalProcess.Location = new System.Drawing.Point(352, 93);
            this.txtTotalProcess.Name = "txtTotalProcess";
            this.txtTotalProcess.Size = new System.Drawing.Size(38, 20);
            this.txtTotalProcess.TabIndex = 25;
            this.txtTotalProcess.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(242, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "Processes completed";
            // 
            // txtCurrentProcess
            // 
            this.txtCurrentProcess.Location = new System.Drawing.Point(352, 118);
            this.txtCurrentProcess.Name = "txtCurrentProcess";
            this.txtCurrentProcess.Size = new System.Drawing.Size(38, 20);
            this.txtCurrentProcess.TabIndex = 27;
            this.txtCurrentProcess.Text = "0";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 484);
            this.Controls.Add(this.txtCurrentProcess);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTotalProcess);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbVersions);
            this.Controls.Add(this.cbLogons);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clbVersions);
            this.Controls.Add(this.clbLogon);
            this.Controls.Add(this.btnRun);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nexgen PLB Compiler";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.CheckedListBox clbLogon;
        private System.Windows.Forms.CheckedListBox clbVersions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbLogons;
        private System.Windows.Forms.CheckBox cbVersions;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTotalProcess;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCurrentProcess;
    }
}

