CREATE TYPE level_other_income_tt AS TABLE(
level_other_income_id	INT	NULL
,is_edited	CHAR(1)	NULL
,level_id	INT	NULL
,other_income_id	INT	NULL
,amount	DECIMAL(20)	NULL)