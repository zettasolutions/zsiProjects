CREATE TYPE inactive_types_tt AS TABLE(
inactive_type_code	NCHAR(20)	NULL
,inactive_type_desc	NVARCHAR(100)	NULL)