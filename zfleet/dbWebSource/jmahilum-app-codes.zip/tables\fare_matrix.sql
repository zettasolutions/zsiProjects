CREATE TABLE fare_matrix(
fare_id	INT	NOT NULL
,base_fare	DECIMAL(20)	NULL
,base_kms	DECIMAL(20)	NULL
,succeeding_km_fare	DECIMAL(20)	NULL
,vehicle_type_id	INT	NULL)