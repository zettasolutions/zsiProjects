CREATE TYPE master_pages_tt AS TABLE(
master_page_id	INT	NULL
,master_page_name	VARCHAR(50)	NOT NULL)