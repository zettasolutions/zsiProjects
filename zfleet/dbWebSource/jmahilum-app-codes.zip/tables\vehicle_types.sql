CREATE TABLE vehicle_types(
vehicle_type_id	INT	NOT NULL
,vehicle_type	NVARCHAR(100)	NULL)