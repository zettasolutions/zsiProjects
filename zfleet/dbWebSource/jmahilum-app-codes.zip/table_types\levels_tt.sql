CREATE TYPE levels_tt AS TABLE(
level_id	INT	NULL
,is_edited	CHAR(1)	NULL
,level_no	INT	NULL
,level_title	NVARCHAR(100)	NULL
,level_description	VARCHAR(0)	NULL)