CREATE TYPE themes_tt AS TABLE(
theme_id	INT	NULL
,theme_name	VARCHAR(300)	NULL)