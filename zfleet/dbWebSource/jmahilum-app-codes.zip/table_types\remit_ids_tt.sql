CREATE TYPE remit_ids_tt AS TABLE(
id	INT	NULL
,collection_type	NVARCHAR(40)	NULL)