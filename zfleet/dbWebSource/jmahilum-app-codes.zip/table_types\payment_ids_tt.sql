CREATE TYPE payment_ids_tt AS TABLE(
payment_id	INT	NULL)