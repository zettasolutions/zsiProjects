CREATE TYPE routes_tt AS TABLE(
route_id	INT	NULL
,is_edited	CHAR(1)	NULL
,route_code	VARCHAR(10)	NULL
,route_desc	VARCHAR(100)	NULL)